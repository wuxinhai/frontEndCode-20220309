function outCode(){
    alert("我是定义在.js文件中的方法!");
}